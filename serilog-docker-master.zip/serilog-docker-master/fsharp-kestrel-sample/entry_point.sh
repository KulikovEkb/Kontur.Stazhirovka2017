#!/bin/bash

cd sample
dotnet restore
dotnet run